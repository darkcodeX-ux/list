# LazyRev
LazyRev for Lazy People

<h1>LazyRev release!</h1>

Fitur:
- Threading
- ViewDNS API
- Detect same IP (kalo ada ip yang udah di reverse langsung skip)
- Unlimited
- .EXE version (Santuy bukan ransom/virus)

NB: Sebelum download wajib follow github gw ya tod, jangan lupa klik star nya juga >:(

Link : https://github.com/justakazh/LazyRev-V.2
<br>
<h1>LazyRev Premium Has Been Release!!!</h1>
<br>
<b>buy lazyrev premium for just $ 5 per week!</b>
<br>
<ul>
	<li>
		<b>Features:</b>
	</li>
	<li>HACKERTARGET API</li>
	<li>VIEWDNS API</li>
	<li>MULTIPROCCESSING</li>
	<li>REMOVE DUPLICATE REQUEST IP</li>
	<li>FILTER RESULT</li>
</ul>
<br>
<h2>Contact for buy license: <a href="https://fb.com/justakazh">Akazh</a></h2>
<br>
<img src="Capture.PNG">
